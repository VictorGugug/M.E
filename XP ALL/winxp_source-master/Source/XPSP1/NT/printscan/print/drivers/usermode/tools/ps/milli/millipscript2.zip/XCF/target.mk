#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!include ..\..\pscript2.mk


!IF "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT = /Od /Zi /G2 /DPSDEBUG
OPTSPECIAL=/Od /Zi
!ELSE
DBGOPT=/DRELEASE /Ose /G3
OPTSPECIAL=/Od
!ENDIF

OPTS   = /c /W3 /ALw /Gsy /nologo /Gx-
OPTX   = /Zdp1

!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fa
!endif

AFLAGS = /c /Zm /Dmdl_l
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver

!ifdef DBCS
# For FE.
CFLAGS = $(CFLAGS) /DFE_DEVICE
!endif

#  L16EXE = krnl386.exe
#  PROPBINS=$(L16EXE) krnl386.sym krnl386s.sym
#  TARGETS = $(PROPBINS)
#  MFLAGS = -m -nologo

INCLUDE = ..\..\inc;$(ROOT)\printers\drivers\iconlib;$(ROOT)\win\\core\inc;$(INCLUDE)

#List of object files to build:
OBJS   = XCF_CFF.OBJ XCF_CSTR.OBJ XCF_DA.OBJ\
XCF_FP.OBJ XCF_MISC.OBJ XCF_T1.OBJ
#XCF_CMD.OBJ XCF_DUMP.OBJ 

xcf.lib: $(OBJS)
   $(LB) xcf.lib @<<
-+$(OBJS: = &^
-+)
xcf.lst;

<<NOKEEP

default : $(OBJS) xcf.lib

all     :  $(OBJS) xcf.lib



GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

generic.obj: ..\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\generic.c


;--------------------------------------------------------------------------;
;                                                                          ;
;   Copyright (C) 1990 by Microsoft Inc.                                   ;
;                                                                          ;
;   oct-93 MikeSh:							   ;
;	Sped up functions and removed dead code				   ;
;	GetFreeMemInfo moved to bandsize.c				   ;
;   dec-93 Srini (srinivac):                                               ;
;	Moved to pscript. Removed unnecessary functions                    ;
;       Modified SetByteValue to really accept a byte value                ;
;   mar-94 Srini (srinivac):                                               ;
;       Merged in code from Adobe                                          ;
;--------------------------------------------------------------------------;

	title   Pscript TEXT segment speedy functions
	page    ,132
.386
.xlist
.list


_UTILS SEGMENT PUBLIC USE16 'code'
assume	cs:_UTILS
assume  ds:nothing


;       MemCopy:   copy 'cnt' number of Bytes from 'src' to 'dst'

MemCopy	PROC FAR PASCAL, dst:DWORD, src:DWORD, cnt:DWORD

	push    edi              ; save 32-bit regs, or you'll be sorry
	push    esi
	mov	ax, ds

	cld

	les	di, dst
	lds	si, src

	movzx   esi, si
	movzx   edi, di

	mov	ecx, cnt
	shr     ecx, 2

	rep	movsd DWORD PTR es:[edi], DWORD PTR ds:[esi]

	mov	ecx, cnt
	and	ecx, 3

	rep	movsb BYTE PTR es:[edi], BYTE PTR ds:[esi]

	pop     esi          ; restore registers
	pop     edi
	mov	ds, ax

	ret

MemCopy	ENDP

;       MemComp:   compare 'cnt' number of Bytes from 'src' with 'dst'

MemComp    PROC FAR PASCAL, dst:DWORD, src:DWORD, cnt:DWORD

	push    edi              ; save 32-bit regs, or you'll be sorry
	push    esi
	mov     bx, ds

	cld
	mov     ax, 0001    ; set result value to 1 (initially)

	les     di, dst
	lds     si, src
	
	movzx   esi, si
	movzx   edi, di

	mov     ecx, cnt
	shr     ecx, 2

	repe    cmpsd DWORD PTR ds:[esi], DWORD PTR es:[edi]
	JNZ     @F
	mov     ecx, cnt
	and     ecx, 3

	repe    cmpsb BYTE PTR ds:[esi], BYTE PTR es:[edi]
	JNZ     @F
	xor     ax, ax
@@:
	pop     esi          ; restore registers
	pop     edi
	mov     ds, bx
	ret

MemComp    ENDP


;       MemSet: sets 'cnt' bytes starting at 'dst' to 'val'
;

MemSet PROC FAR PASCAL, dst:DWORD, val:WORD, cnt:DWORD

	push  	edi
	cld

	les	di, dst		; es:di = dst
	movzx	edi, di

	mov	al, BYTE PTR val
	mov	ah, al
	mov	bx, ax
	shl	eax, 16
	mov	ax, bx		; eax = val;val:val;val
	mov	ecx, cnt	; ecx = byte count
	mov	bx, cx
	shr	ecx, 2

	rep	stosd DWORD PTR es:[edi]

	jnc	@F		; 'C' bit still set from "shr cx,2" above
	mov	WORD PTR es:[edi], ax	; store spare word
	add	di, 2
@@:
	test	bx, 1		; odd count?
	jz	@F
	mov	BYTE PTR es:[di], al	; store spare byte
@@:
	pop	edi
	ret

MemSet  ENDP


_UTILS ENDS

END

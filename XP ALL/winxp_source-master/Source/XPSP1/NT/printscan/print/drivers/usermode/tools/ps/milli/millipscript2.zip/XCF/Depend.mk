!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

./xcf_cff.obj ./xcf_cff.lst: ../xcf_cff.c  \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_cmd.obj ./xcf_cmd.lst: ../xcf_cmd.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_cstr.obj ./xcf_cstr.lst:  ../xcf_cstr.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_da.obj ./xcf_da.lst: ../xcf_da.c \
		../../../$(MYDIR)/inc/generic2.h \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_dump.obj ./xcf_dump.lst: ../xcf_dump.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_fp.obj ./xcf_fp.lst: ../xcf_fp.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_misc.obj ./xcf_misc.lst: ../xcf_misc.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 

./xcf_t1.obj ./xcf_t1.lst: ../xcf_t1.c \
        ../xcf_base.h \
        ../xcf_da.h \
        ../xcf_dtop.h \
        ../xcf_expc.h \
        ../xcf_expe.h \
        ../xcf_exsc.h \
        ../xcf_ics.h \
        ../xcf_isoc.h \
        ../xcf_mac.h \
        ../xcf_mkbf.h \
        ../xcf_mmff.h \
        ../xcf_priv.h \
        ../xcf_pub.h \
        ../xcf_sstr.h \
        ../xcf_stde.h \
        ../xcf_t13.h \
        ../xcf_txop.h 



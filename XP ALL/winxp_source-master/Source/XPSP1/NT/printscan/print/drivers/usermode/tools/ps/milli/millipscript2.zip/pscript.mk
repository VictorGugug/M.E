#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1991
#       All Rights Reserved.
#                                                                          
#       PSCRIPT4 project makefile include
#
#############################################################################
WANT_C816=1
IS_OEM=1
MASM6=TRUE

!ifndef DEVROOT
DEVROOT=\dev
!endif

!ifndef WINROOT
WINROOT=\win
!endif

# INCFLAGS = $(INCFLAGS) -A=mac -A=ver

!IF "$(VER)" == "debug.d" || "$(VER)" == "retail.d"
DBCS=1
!endif

!include $(DEVROOT)\master.mk



#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

!IFNDEF PS41DIR
PS41DIR=ps40
!ENDIF


!include $(ROOT)\printers\drivers\$(PS41DIR)\$(MYDIR)\pscript2.mk

INCLUDE=..\..\..\help;..\..\inc;$(ROOT)\win\core\inc;$(ROOT)\printers\drivers\iconlib;$(INCLUDE)

#Compiler options
!if "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT=/Od /Zi /G2
!else
DBGOPT=/Ose /DRELEASE /G3
!endif

OPTS   = /c /W3 /ALw /Gsy /nologo
OPTX   = /Zdp1

!ifdef ADOBE_WEB
OPTS=$(OPTS) /DADOBE_WEB
!endif

!ifdef PANEURO
OPTS=$(OPTS) /DPANEURO
!endif


!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fa
!endif

!ifdef DBCS
LCFLAGS=$(LCFLAGS) /DFE_DEVICE /DFE_BOLD
!endif

AFLAGS = /c /Zm
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver

!ifdef T3OUTLINE
CFLAGS = $(CFLAGS) -DT3OUTLINE
!endif

!ifdef MICROSOFT_DRIVER_VERSION
CFLAGS = $(CFLAGS) -DUSE_WHATSTHIS_HELP -DMICROSOFT_DRIVER_VERSION
!endif

#OBJS   = GENERIC.OBJ RESOURCE.OBJ\
OBJS   = RESOURCE.OBJ\
jobdlg.obj ABOUTDLG.OBJ DLGSUTIL.OBJ\
DRVSTATE.OBJ KEYWFUNC.OBJ\
PRNTRMGR.OBJ STATMACH.OBJ TTDIALOG.OBJ\
# propsh.obj paper.obj custpap.obj device.obj spin.obj\
paper.obj margins.obj colordlg.obj custpap.obj device.obj spin.obj\
graphics.obj psdlg.obj fonts.obj advanced.obj lcalls.obj\
port.obj wpxinfo.obj upgrade.obj icm.obj uic.obj help.obj\
oemstubs.obj csprof.obj watermar.obj trigs.obj\
getcsa.obj getcrd.obj profcrd.obj


#Build all the object files

dmg.lib: $(OBJS)
   $(LB) dmg.lib @<<
-+$(OBJS: = &^
-+)
dmg.lst;

<<NOKEEP

default : $(OBJS) dmg.lib

all     :  $(OBJS) dmg.lib


GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

!ifdef DBCS
GENCFLAGS = $(GENCFLAGS) /DFE_DEVICE /DFE_BOLD
!endif

generic.obj: ..\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\generic.c


#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1991
#       All Rights Reserved.
#                                                                          
#       PSCRIPT4 project makefile include
#
#############################################################################
WANT_C816=1

# INCFLAGS = $(INCFLAGS) -A=mac -A=ver

!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

!IFNDEF PS41DIR
PS41DIR=ps40
!ENDIF


INCLUDE=$(DDKLIB)\..\inc;$(INCLUDE)

!include $(ROOT)\printers\drivers\$(PS41DIR)\$(MYDIR)\pscript2.mk



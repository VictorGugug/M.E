#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!include ..\..\pscript2.mk


!IF "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT = /Od /Zi /G2
OPTSPECIAL=/Od /Zi
!ELSE
DBGOPT=/DRELEASE /Ose /G3
OPTSPECIAL=/Od
!ENDIF

OPTS   = /c /W3 /ALw /Gsy /nologo
OPTX   = /Zdp1

!ifdef ADOBE_WEB
OPTS=$(OPTS) /DADOBE_WEB
!endif

!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fa
!endif

!ifdef DBCS
LCFLAGS=$(LCFLAGS) /DFE_DEVICE /DDBCS
!endif

AFLAGS = /c /Zm
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver

!ifdef MICROSOFT_DRIVER_VERSION
CFLAGS = $(CFLAGS) -DMICROSOFT_DRIVER_VERSION
!endif

#  L16EXE = krnl386.exe
#  PROPBINS=$(L16EXE) krnl386.sym krnl386s.sym
#  TARGETS = $(PROPBINS)
#  MFLAGS = -m -nologo

INCLUDE = ..\..\inc;$(ROOT)\printers\drivers\iconlib;$(WINROOT)\core\inc;$(INCLUDE)

#List of object files to build:
#OBJS   = GENERIC.OBJ FILEMAN1.OBJ PFMPARSE.OBJ\
OBJS   = FILEMAN1.OBJ PFMPARSE.OBJ OLDWPD.OBJ\
PARSE1.OBJ PARSE2.OBJ PARSE3.OBJ PARSE4.OBJ

wpx.lib: $(OBJS)
   $(LB) wpx.lib @<<
-+$(OBJS: = &^
-+)
wpx.lst;

<<NOKEEP

default : $(OBJS) wpx.lib

all     :  $(OBJS) wpx.lib



GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

!ifdef DBCS
GENCFLAGS = $(GENCFLAGS) /DFE_DEVICE /DFE_BOLD /DDBCS
!endif

generic.obj: ..\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\generic.c


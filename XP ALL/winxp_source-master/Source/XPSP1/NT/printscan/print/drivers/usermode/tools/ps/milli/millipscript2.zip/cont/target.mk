#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!include ..\cont.MK

#Compiler options
!if "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT=/Od /Zi  /G2
!else
DBGOPT=/Ose /DRELEASE /G3
!endif

OPTS   = /c /W3 /ALw /Gsy /nologo
OPTX   = /Zdp1

!ifdef ADOBE_WEB
OPTS=$(OPTS) /DADOBE_WEB
!endif

!ifdef PANEURO
OPTS=$(OPTS) /DPANEURO
!endif

!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fc
!endif

AFLAGS = /c /Zm
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver

!ifdef DBCS
#For FE.
CFLAGS = $(CFLAGS) /DFE_DEVICE /DFE_BOLD
!endif

!ifdef T3OUTLINE
CFLAGS = $(CFLAGS) /DT3OUTLINE
!endif

!ifdef MICROSOFT_DRIVER_VERSION
CFLAGS = $(CFLAGS) -DMICROSOFT_DRIVER_VERSION
!endif

#  L16EXE = krnl386.exe
#  PROPBINS=$(L16EXE) krnl386.sym krnl386s.sym
#  TARGETS = $(PROPBINS)
#  MFLAGS = -m -nologo

INCLUDE = ..\..\inc;$(ROOT)\printers\drivers\iconlib;$(ROOT)\dev\ddk\inc;$(INCLUDE);
#INCLUDE = ..\..\inc;$(WINROOT)\drivers\printers\iconlib;$(WINROOT)\core\inc;$(INCLUDE)


#List of object files to build:
#LIBOBJS   = GENERIC.OBJ DEVMODE.OBJ STUBS.OBJ CFONT.OBJ CUTILS.OBJ FNTCACHE.OBJ\
LIBOBJS   = DEVMODE.OBJ STUBS.OBJ CFONT.OBJ CUTILS.OBJ FNTCACHE.OBJ\
EXTTEXT.OBJ EXTTEXTW.OBJ GETCHARW.OBJ STRBLT.OBJ ESCSTUBS.OBJ ESCSTUB2.OBJ\
CSTUBS.OBJ CESCAPES.OBJ CGDIOBJ.OBJ\
PIXEL.OBJ OUTPUT.OBJ ENUMOBJ.OBJ ENUMFONT.OBJ ESCAPES.OBJ ENUMSTUB.OBJ\
COLORINF.OBJ BITBLT.OBJ DLLSTUFF.OBJ STRETCHD.OBJ DIBTODEV.OBJ DEVCAPS.OBJ\
STRETCHB.OBJ CONTROL.OBJ DISABLE.OBJ ENABLE.OBJ SCANLR.OBJ REALIZE.OBJ UTILS.OBJ\
TRIG.OBJ ALERT.OBJ REGSETUP.OBJ

LIBOBJS  = $(LIBOBJS) LIBENTRY.OBJ

!if (defined(PS_PROFILE) || defined(STATPROF) || defined(PS_MEMTRACE))
LIBOBJS = $(LIBOBJS) ps_debug.obj
!ifdef STATPROF
LIBOBJS = $(LIBOBJS) stat.obj
!endif
!endif

cont.lib: $(LIBOBJS)
   $(LB) cont.lib @<<
-+$(LIBOBJS: = &^
-+)
cont.lst;

<<NOKEEP

default : $(LIBOBJS) cont.lib

all     :  $(LIBOBJS) cont.lib


GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

generic.obj: ..\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\generic.c






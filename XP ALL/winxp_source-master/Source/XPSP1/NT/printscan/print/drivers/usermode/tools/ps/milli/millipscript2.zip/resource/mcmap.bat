echo off
echo --- Make CMAP files for CJK ---
echo - set lib/inc for building MAKECMAP.exe
SET LIB=\dev\lib16;\dev\sdk\LIB16;\dev\tools\c816\lib
SET INCLUDE=\dev\tools\c816\inc;\dev\inc16;\dev\sdk\inc16;..\..\..\..\..\core\inc;..\inc;..\..\..\iconlib
set IS_16=1
echo : Building MAKECMAP.EXE ....
nmake -fmakecmap.mak

echo : Create CMAP files ...
echo : cmap_sj.ps cmap_uh.ps cmap_jo.ps cmap_gb.ps cmap_b5.ps
pause
makecmap -c128 cmap_sj.ps -c129 cmap_uh.ps -c130 cmap_jo.ps -c134 cmap_gb.ps -c136 cmap_b5.ps



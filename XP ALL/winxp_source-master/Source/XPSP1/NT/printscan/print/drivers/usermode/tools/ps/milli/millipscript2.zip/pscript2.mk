#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1991
#       All Rights Reserved.
#
#       PSCRIPT2 project makefile include
#
#############################################################################
WANT_C816=1
IS_OEM=1
MASM6=TRUE

MICROSOFT_DRIVER_VERSION=TRUE

!IFNDEF PS41DIR
PS41DIR=ps40
!ENDIF

!include $(ROOT)\printers\drivers\$(PS41DIR)\pscrpt41.mk



!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

.\parsett.obj .\parsett.lst: ..\source\parsett.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\ufl.obj .\ufl.lst: ..\source\ufl.c\
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\uflmem.obj .\uflmem.lst: ..\source\uflmem.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\uflsproc.obj .\uflsproc.lst: ..\source\uflsproc.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\uflstrm.obj .\uflstrm.lst: ..\source\uflstrm.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\ufo.obj .\ufo.lst: ..\source\ufo.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\ufocff.obj .\ufocff.lst: ..\source\ufocff.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h \
	..\..\..\$(MYDIR)\xcf\xcf_pub.h


.\ufot42.obj .\ufot42.lst: ..\source\ufot42.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\ufottt1.obj .\ufottt1.lst: ..\source\ufottt1.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h


.\ufottt3.obj .\ufottt3.lst: ..\source\ufottt3.c \
        ..\api\parsett.h \
        ..\api\ufl.h \
        ..\api\uflclien.h \
        ..\config\win\uflcnfig.h \
        ..\api\uflerr.h \
        ..\api\uflmath.h \
        ..\api\uflmem.h \
        ..\api\uflpriv.h \
        ..\api\uflps.h \
        ..\api\uflstd.h \
        ..\api\uflstrm.h \
        ..\api\ufltypes.h \
        ..\api\uflvm.h \
        ..\api\ufo.h \
        ..\api\ufocff.h \
        ..\api\ufot42.h \
        ..\api\ufottt1.h \
        ..\api\ufottt3.h





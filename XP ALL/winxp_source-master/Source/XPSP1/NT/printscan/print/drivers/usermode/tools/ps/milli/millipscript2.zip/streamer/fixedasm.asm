        page    60,132
        TITLE   FIXEDASM.ASM: Fast Intel Version of Adobe Fixed-Type Functions

        COMMENT !

        typedef long int Fixed;           i = 15, f = 16, range: -32769..32768
        #define fixedScale 65536.0
        typedef long int Frac;            i = 1, f = 30, range: -3..2
        #define fracScale 1073741824.0

        Fixed-point representations use a sign bit, i integer bits, and f
        fraction bits, with a scale of 2**f.  The underlying representation
        is a long int.  The long int value n represents the fixed-point value
        n/(2**f).

        All procedures return a correctly signed "infinity" (PosInf or
        NegInf) if an overflow occurs, and return zero if an underflow
        occurs.

        This program tests for processor type (8086, 80286 or 80386), and
        uses the available facilities accordingly, in order to obtain maximum
        performance.

        By means of the -Dmdl_x command line option, where x is one of the
        set {t s m c l h}, the module may be assembled for operation with any
        memory model.

        The following functions are implemented here:

             Fixed fixmul(Fixed x, Fixed y);

             Frac  fracmul(Frac x, Frac y);

             Fixed fxfrmul(Fixed x, Frac y);

             Fixed fixdiv(Fixed x, Fixed y);

             Fixed fracratio(Frac x, Frac y);

             Frac  fixratio(Fixed x, Fixed y);

             Frac  fracdiv(Frac x, Frac y);

             UFrac fracsqrt(UFrac x);

        Paul N. Sholtz, July 1, 1990.
        Revised, September 6, 1991, January 9, 1992.
        fracdiv added, June 15, 1992.
        fracsqrt added, June 22, 1992.

        !
        page

        include cintf.mac
        MODELSET

        .data
        align 2

posinflo equ    0ffffh                  ; most positive value of type Fixed
posinfhi equ    07fffh
neginflo equ    00000h                  ; most negative value of type Fixed
neginfhi equ    08000h

; Note: Symbol @P, which is used to access parameters from the stack,
; is defined by the modelset macro.

; Local data: the following symbol is used to store intermediate data on
; the stack.
gdtreg  equ     fword ptr ss:[sp-6]     ; temporary storage for SGDT in PROCTEST
gdtreg5 equ     byte ptr ss:[sp-1]      ; last byte stored by SGDT

; The following may not be kept on the stack, because bp is not available
; to access them at all times.
aword   dw      0                       ; intermediate operands
bword   dw      0
divscal dw      0                       ; division scaling shift
sgnres  db      0                       ; sign of result
proctype db     0                       ; processor type:
                                        ;   00 = not yet tested
                                        ;   ff = 80286 processor
                                        ;   01 = 80386 processor
sqrtscal equ    sgnres                  ; fracsqrt/8086 scaling indicator
        .code
        .8086
        page
        COMMENT !


        fixmul: Calculate Product of Two Fixed Numbers

        !

        .data
fixmul_ent dw   offset fixmul0
fixmul_386 dw   offset fixmul3
fixmul_286 dw   offset fixmul2

        .code
        FUNC    fixmul
        jmp     fixmul_ent

fixmul0:
        call    procset                 ; test processor and set jump addresses
        jmp     fixmul_ent              ; go do the function
        page
; 80386/80486 Code for fixmul

        align 2
        .386
fixmul3:
        push    bp
        mov     bp,sp

; on entry, a:b and c:d are on stack

        mov     eax,dword ptr [@P]      ; multiplicand to EAX
        imul    dword ptr [@P+4]        ; form product
        or      edx,edx                 ; set flags
        js      short A1                ; branch if negative result
        add     eax,8000h               ; round result (8000 is 1/2 of lsb)
        adc     edx,0                   ; propagate carry to EDX
        cmp     edx,8000h               ; test for overflow
        jae     short A2                ; branch if overflow
        shr     eax,16                  ; format result in DX:AX
        pop     bp
        ret                             ; return to caller

; Result is negative; since truncation makes the absolute value larger (as
; opposed to smaller in the positive case) we reduce the value by 1/2 of the
; lsb of the result.  This can make the result positive, so we must check
; for that additional case.
        align 2
A1:     add     eax,07fffh              ; round result
        adc     edx,0                   ; propagate carry
        jns     short A1a               ; check for positive result
        cmp     edx,0ffff8000h          ; test for underflow
        jb      short A3                ; branch if underflow
A1a:    shr     eax,16                  ; format result in DX:AX
        pop     bp
        ret                             ; return to caller

        align 2
A2:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     bp
        ret                             ; return to caller

        align 2
A3:     mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     bp
        ret                             ; return to caller
        page
; 8086/80286 Code for fixmul

;       SI,DI: Result register
;       DX,AX: Multiplication register
;       BX,CX: Multiplier register
;
;       Multiplicand is a:b; multiplier is c:d
;       Product is the following sum:
;
;                  ---------------------------------
;                  |   0   |   0   |     d * b     |
;                  ---------------------------------
;                  ---------------------------------
;                  |   0   |     d * a     |   0   |
;                  ---------------------------------
;                  ---------------------------------
;                  |   0   |     c * b     |   0   |
;                  ---------------------------------
;                  ---------------------------------
;                  |     c * a     |   0   |   0   |
;                  ---------------------------------
;                          -----------------
;                  Result: |       |       |
;                          -----------------

        align 2
        .8086
fixmul2:
        push    bp
        mov     bp,sp
        push    si
        push    di

; On entry, a:b and c:d are on stack
        mov     cx,word ptr [@P+4]      ; get argument d
        mov     bx,word ptr [@P+6]      ; get argument c
        mov     ax,word ptr [@P+2]      ; get argument a
        mov     bp,word ptr [@P]        ; get argument b
        mov     dh,ah                   ; save sign of a
        or      ax,ax                   ; test sign of a
        jns     short Ba                ; ns: multiplicand positive
        neg     ax                      ; negative; get abs()
        neg     bp
        sbb     ax,0
Ba:     mov     aword,ax                ; store abs(a) value

        or      bx,bx                   ; test sign of c
        jns     short Bb                ; ns: multiplier positive
        not     dh                      ; invert result sign
        neg     bx                      ; negative; get abs()
        neg     cx
        sbb     bx,0

Bb:     mov     sgnres,dh               ; save (h/o bit significant)
        mov     ax,bp                   ; get b
        mul     cx                      ; form product d * b
        rcl     ax,1                    ; move h/o bit to cy; d*b >= 0.5
        adc     dx,0                    ; round h/o part
        mov     di,dx                   ; move to result accumulator
        sub     si,si                   ; zero h/o result accumulator
        mov     ax,aword                ; get a
        mul     cx                      ; form product d * a
        add     di,ax                   ; add l/o part to result
        adc     si,dx                   ; add h/o part to result, with carry
        mov     ax,bp                   ; get b
        mul     bx                      ; form product c * b
        add     di,ax                   ; add to result
        adc     si,dx
        jo      short Bd                ; overflow: result too big
        mov     ax,aword                ; get argument a
        mul     bx                      ; form product c * a
        jc      short Bd                ; carry: result too big (DX <> 0)
        or      ax,ax                   ; test sign
        js      short Bd                ; sign: result too big
        add     si,ax                   ; add to result
        jo      short Bd                ; overflow: result too big
        test    sgnres,080h             ; test result sign
        jz      short Bc                ; 0: positive
        neg     si                      ; negate result
        neg     di
        sbb     si,0

Bc:     mov     dx,si                   ; return result in registers
        mov     ax,di
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Bd:     test    sgnres,080h             ; test sign of result
        jz      short Be                ; 0: positive
        mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Be:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller
        ENDFUNC fixmul
        page
        COMMENT !


        fracmul: Calculate Product of Two Frac Numbers

        !

        align 2

        .data
frcmul_ent dw   offset frcmul0
frcmul_386 dw   offset frcmul3
frcmul_286 dw   offset frcmul2

        .code
        FUNC    fracmul

        PUBLIC  _fxfrmul                ; synonym for fracmul
_fxfrmul:
        jmp     frcmul_ent

frcmul0:
        call    procset                 ; test processor and set jump addresses
        jmp     frcmul_ent              ; go do the function
        page
; 80386/80486 Code for fracmul

        align 2
        .386
frcmul3:
        push    bp
        mov     bp,sp

; On entry, a:b and c:d are on stack

        mov     eax,dword ptr [@P]      ; multiplicand to EAX
        imul    dword ptr [@P+4]        ; form product
        or      edx,edx                 ; set flags
        js      short C1                ; branch if negative result
        add     eax,20000000h           ; round result
        adc     edx,0                   ; propagate carry to EDX
        cmp     edx,20000000h           ; test for overflow
        jae     short C2                ; branch if overflow
        shld    edx,eax,2               ; scale result
        mov     ax,dx                   ; move l/o result to AX (rt half EDX)
        shr     edx,16                  ; move h/o result to DX (lft half EDX)
        pop     bp
        ret                             ; return to caller

; Result is negative; since truncation makes the absolute value larger (as
; opposed to smaller in the positive case) we reduce the value by 1/2 of the
; lsb of the result.  This can make the result positive, so we must check
; for that additional case.
        align 2
C1:     add     eax,1fffffffh           ; round result
        adc     edx,0                   ; propagate carry
        jns     short C1a               ; test for positive result
        cmp     edx,0e0000000h          ; test for underflow
        jb      short C3                ; branch if underflow
C1a:    shld    edx,eax,2               ; scale result
        mov     ax,dx                   ; move l/o result to AX (rt half EDX)
        shr     edx,16                  ; move h/o result to DX (lft half EDX)
        pop     bp
        ret                             ; return to caller

        align 2
C2:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     bp
        ret                             ; return to caller

        align 2
c3:     mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     bp
        ret                             ; return to caller
        page
; 8086/80286 Code for fracmul

;       BX,CX,SI,DI: Result register
;       DX,AX: Multiplication register
;
;       Multiplicand is a:b; multiplier is c:d
;       Product is the following sum
;
;                  ---------------------------------
;                  |   0   |   0   |     d * b     |
;                  ---------------------------------
;                  ---------------------------------
;                  |   0   |     d * a     |   0   |
;                  ---------------------------------
;                  ---------------------------------
;                  |   0   |     c * b     |   0   |
;                  ---------------------------------
;                  ---------------------------------
;                  |     c * a     |   0   |   0   |
;                  ---------------------------------
;                    -----------------
;                    |       |       |  : Result
;                    -----------------

        align 2
        .8086
frcmul2:
        push    bp
        mov     bp,sp
        push    si
        push    di

; On entry, a:b are in DX:AX; c:d are on stack
        mov     dx,word ptr [@P+2]      ; get argument a
        mov     ax,word ptr [@P]        ; get argument b
        mov     ch,dh                   ; save sign of a
        or      dx,dx                   ; test sign of a
        jns     short Ea                ; ns: multiplicand positive
        neg     dx                      ; negative; get abs()
        neg     ax
        sbb     dx,0

Ea:     mov     aword,dx                ; store abs(a)
        mov     bword,ax                ; store abs(b)
        mov     dx,word ptr [@P+6]      ; get argument c
        mov     ax,word ptr [@P+4]      ; get argument d
        or      dx,dx                   ; test sign of c
        jns     short Eb                ; ns: multiplier positive
        not     ch                      ; invert result sign
        neg     dx                      ; negative; get abs()
        neg     ax
        sbb     dx,0
        mov     word ptr [@P+6],dx      ; store abs(c)
        mov     word ptr [@P+4],ax      ; store abs(d)

Eb:     mov     sgnres,ch               ; save (h/o bit significant)
        mov     ax,bword                ; get argument b
        mul     word ptr [@P+4]         ; form product d * b
        mov     di,ax                   ; move to result accumulator
        mov     si,dx
        sub     cx,cx                   ; zero h/o result accumulator
        sub     bx,bx
        mov     ax,aword                ; get argument a
        mul     word ptr [@P+4]         ; form product d * a
        add     si,ax                   ; add l/o part to result
        adc     cx,dx                   ; add h/o part to result, with carry
        mov     ax,bword                ; get argument b
        mul     word ptr [@P+6]         ; form product c * b
        add     si,ax                   ; add to result
        adc     cx,dx
        mov     ax,aword                ; get argument a
        mul     word ptr [@P+6]         ; form product c * a
        add     cx,ax                   ; add to result
        adc     bx,dx

; Now must adjust binary point of 64 bit result (BX:CX:SI:DI) left by 2 bits.
; First round result at bit 14 of SI.
        test    si,2000h                ; test bit to right of final result
        jz      short Ec
        add     si,4000h                ; increment final result
        adc     cx,0                    ; propagate carries
        adc     bx,0

Ec:     rol     si,1                    ; shift BX:CX:SI left by 2; bits pass
        rcl     cx,1                    ; ...between registers via carry flag
        rcl     bx,1
        jo      short Fa                ; overflow indicates number too large
        rol     si,1
        rcl     cx,1
        rcl     bx,1
        jo      short Fa
        test    sgnres,080h             ; test result sign
        jz      short Ed                ; 0: positive
        neg     bx                      ; negate result
        neg     cx
        sbb     bx,0

Ed:     mov     dx,bx                   ; return result in registers
        mov     ax,cx
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Fa:     test    sgnres,080h             ; test sign of result
        jz      short Fb                ; 0: positive
        mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Fb:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller
        ENDFUNC fracmul
        page
        COMMENT !


        fixdiv: Calculate Quotient of Two Fixed Numbers

        fracratio: Calculate Quotient of Two Frac Numbers (Fixed Result)

        !

        align 2

        .data
fixdiv_ent dw   offset fixdiv0
fixdiv_386 dw   offset fixdiv3
fixdiv_286 dw   offset fixdiv2

        .code
        FUNC    fixdiv

        PUBLIC  _fracratio              ; synonym for fixdiv
_fracratio:
        jmp     fixdiv_ent

fixdiv0:
        call    procset                 ; test processor and set jump addresses
        jmp     fixdiv_ent              ; go do the function
        page
; 80386/80486 Code for fixdiv

        align 2
        .386
fixdiv3:
        push    bp
        mov     bp,sp

; On entry, dividend and divisor are on stack
        mov     eax,dword ptr [@P]      ; get dividend into EDX:EAX
        cdq                             ; perform sign extension to EDX:EAX
        shld    edx,eax,17              ; scale dividend in EDX:EAX
        shl     eax,17                  ; now have dividend x 2 in EDX:EAX
        mov     ecx,edx                 ; keep sign of result in ECX
        or      edx,edx                 ; set flags for dividend
        jns     short G1
        neg     edx                     ; abs(dividend)
        neg     eax
        sbb     edx,0

G1:     mov     ebx, dword ptr [@P+4]   ; get divisor
        xor     ecx,ebx                 ; set result sign
        or      ebx,ebx                 ; set flags for divisor
        jns     short G2
        neg     ebx                     ; abs(divisor)

G2:     cmp     edx, ebx                ; compare dividend:divisor
        jae     short G4                ; branch if it will overflow
        div     ebx                     ; perform the division
        shr     eax, 1                  ; remove the x 2; l/o bit to Carry
        adc     eax, 0                  ; add the Carry to round result
        or      ecx,ecx                 ; test sign of result
        js      short G3                ; branch if negative
        mov     dx,ax                   ; l/o part of result to DX
        shr     eax,16                  ; h/o part of result to AX
        xchg    dx,ax                   ; proper form for return value
        pop     bp
        ret                             ; return to caller

        align 2
G3:     neg     eax                     ; negate result
        mov     dx,ax                   ; l/o part of result to DX
        shr     eax,16                  ; h/o part of result to AX
        xchg    dx,ax                   ; proper form for return value
        pop     bp
        ret                             ; return to caller

G4:     or      ecx,ecx                 ; overflow - test result sign
        js      short G5                ; branch if negative
        mov     ax,posinflo             ; result for overflow
        mov     dx,posinfhi
        pop     bp
        ret                             ; return to caller

G5:     mov     ax,neginflo             ; result for underflow
        mov     dx,neginfhi
        pop     bp
        ret                             ; return to caller
        page
; 8086/80286 Code for fixdiv

;       Algorithm: Repeated subtraction of a 31-bit divisor from a
;                  31-bit dividend.  The divisor is prescaled.
;
;       DX AX: Dividend register.
;
;       SI DI: Divisor register.  Divisor is shifted left until bit 30 of the
;           divisor is a one.  Quotient is shifted left by divisor preshift
;           minus 14, where a negative value represents a right shift.
;
;       BX BP: quotient.
;
;       CX: loop counter.

        align 2
        .8086
fixdiv2:
        push    bp                      ; establish frame pointer
        mov     bp,sp
        push    si
        push    di

; On entry, dividend and divisor are on stack
        mov     ax,word ptr [@P]        ; get l/o dividend
        mov     dx,word ptr [@P+2]      ; get h/o dividend
        mov     ch,dh                   ; save sign of x
        or      dx,dx                   ; test sign of x
        jns     short ga                ; ns: dividend positive
        neg     dx                      ; negative; get abs()
        neg     ax
        sbb     dx,0

Ga:     mov     si,word ptr [@P+6]      ; get h/o y
        mov     di,word ptr [@P+4]      ; get l/o y
        or      si,si                   ; test sign of y
        jns     short gb                ; ns: divisor positive
        not     ch                      ; invert result sign
        neg     si                      ; negative; get abs()
        neg     di
        sbb     si,0

Gb:     mov     sgnres,ch               ; save (h/o bit significant)

; First shift divisor left until it has only one left zero (sign).
        mov     cx,31                   ; total bits in divisor
Gb1:    test    si,04000h               ; test bit 30 of divisor
        jnz     short gb2               ; quit if one
        shl     di,1                    ; shift divisor left 1 bit
        rcl     si,1
        loop    gb1
        jmp     short gh                ; if we get here, the divisor must be
                                        ; ...zero; go return infinity

        align 2
Gb2:    mov     bx,17                   ; calculate final scaling shift
        sub     bx,cx                   ; left shift (31-CX) - 14
        mov     divscal,bx              ; store for later

; Quotient is formed by doing 31 iterations.
        mov     cx,31                   ; set loop counter
        sub     bx,bx                   ; clear quotient
        sub     bp,bp

Gc:     shl     bp,1                    ; open next quotient position
        rcl     bx,1
        cmp     si,dx                   ; test for subtraction in this position
        ja      short ge0               ; dvsr>dvnd: skip subtract
        jb      short gd                ; dvsr<dvnd: go subtract
        cmp     di,ax                   ; dvsr=dvnd: compare l/o portion
        ja      short ge0               ; dvsr>dvnt: skip subtract

Gd:     sub     ax,di                   ; calculate dividend - divisor
        sbb     dx,si
        or      bp,1                    ; insert quotient bit

Ge0:    shl     ax,1                    ; shift dividend left 1 bit
        rcl     dx,1
        loop    gc                      ; continue until count exhausted

; Shift quotient left by DIVSCAL amount (- means right)
        mov     cx,divscal              ; shift count
        or      cx,cx                   ; test for direction
        jz      short ge4               ; 0: no shift needed
        js      short ge2               ; s: negative (right shift)

Ge1:    shl     bp,1                    ; shift divisor left 1 bit
        rcl     bx,1
        jo      short gh                ; overflow: result too large
        loop    ge1
        jmp     short ge4

        align 2
Ge2:    neg     cx                      ; negate shift amount
Ge3:    shr     bx,1                    ; shift right 1 bit
        rcr     bp,1
        loop    ge3

Ge4:    test    sgnres,080h             ; test result sign
        jz      short gf                ; 0: positive
        neg     bx                      ; negate result
        neg     bp
        sbb     bx,0

Gf:     mov     dx,bx                   ; return result in registers
        mov     ax,bp
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Gh:     test    sgnres,080h             ; test sign of result
        jz      short gi                ; 0: positive

        mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Gi:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller
        ENDFUNC fixdiv
        page
        COMMENT !


        fixratio: Calculate Frac Quotient of Two Fixed Numbers

        fracdiv:  Calculate Frac Quotient of Two Frac Numbers
        !

; See fixdiv above for description.

        align 2
        .data
fixrat_ent dw   offset fixrat0
fixrat_386 dw   offset fixrat3
fixrat_286 dw   offset fixrat2

        .code
        FUNC    fixratio
        jmp     fixrat_ent

        PUBLIC  _fracdiv                ; synonym for fixratio
_fracdiv:
        jmp     fixrat_ent

fixrat0:
        call    procset                 ; test processor and set jump addresses
        jmp     fixrat_ent              ; go do the function
        page
; 80386/80486 Code for fixratio

        align 2
        .386
fixrat3:
        push    bp                      ; establish frame pointer
        mov     bp,sp

; On entry, dividend and divisor are on stack
        mov     edx,dword ptr [@P]      ; load dividend into EDX
        sub     eax,eax                 ; clear EAX
        sar     edx,1                   ; scale dividend in EDX:EAX
        rcr     eax,1                   ; dividend x 2 in EDX:EAX
        mov     ecx,edx                 ; keep sign of result in ECX
        or      edx,edx                 ; set flags for dividend
        jns     short I1
        neg     edx                     ; abs(dividend)
        neg     eax
        sbb     edx,0

I1:     mov     ebx, dword ptr [@P+4]   ; get divisor
        xor     ecx,ebx                 ; set result sign
        or      ebx,ebx                 ; set flags for divisor
        jns     short I2
        neg     ebx                     ; abs(divisor)

I2:     cmp     edx, ebx                ; compare dividend:divisor
        jae     short I4                ; branch if it will overflow
        div     ebx                     ; perform the division
        shr     eax, 1                  ; remove the x 2; l/o bit to Carry
        adc     eax, 0                  ; add the Carry to round result
        or      ecx,ecx                 ; test sign of result
        js      short I3                ; branch if negative
        mov     dx,ax                   ; l/o part of result to DX
        shr     eax,16                  ; h/o part of result to AX
        xchg    dx,ax                   ; proper form for return value
        pop     bp
        ret                             ; return to caller

I3:     neg     eax                     ; negate result
        mov     dx,ax                   ; l/o part of result to DX
        shr     eax,16                  ; h/o part of result to AX
        xchg    dx,ax                   ; proper form for return value
        pop     bp
        ret                             ; return to caller

I4:     or      ecx,ecx                 ; overflow - test result sign
        js      short I5                ; branch if negative
        mov     ax,posinflo             ; result for overflow
        mov     dx,posinfhi
        pop     bp
        ret                             ; return to caller

I5:     mov     ax,neginflo             ; result for underflow
        mov     dx,neginfhi
        pop     bp
        ret                             ; return to caller
        page
; 8086/80286 Code for fixratio

        align 2
        .8086
fixrat2:
        push    bp                      ; establish frame pointer
        mov     bp,sp
        push    si
        push    di

; On entry, dividend and divisor are on stack
        mov     ax,word ptr [@P]        ; get l/o dividend
        mov     dx,word ptr [@P+2]      ; get h/o dividend
        mov     ch,dh                   ; save sign of x
        or      dx,dx                   ; test sign of x
        jns     short Ia                ; ns: dividend positive
        neg     dx                      ; negative; get abs()
        neg     ax
        sbb     dx,0

Ia:     mov     si,word ptr [@P+6]      ; get h/o y
        mov     di,word ptr [@P+4]      ; get l/o y
        or      si,si                   ; test sign of y
        jns     short Ib                ; ns: divisor positive
        not     ch                      ; invert result sign
        neg     si                      ; negative; get abs()
        neg     di
        sbb     si,0

Ib:     mov     sgnres,ch               ; save (h/o bit significant)

; First shift divisor left until it has only one left zero (sign).
        mov     cx,31                   ; total bits in divisor
Ib1:    test    si,04000h               ; test bit 30 of divisor
        jnz     short Ib2               ; quit if one
        shl     di,1                    ; shift divisor left 1 bit
        rcl     si,1
        loop    ib1
        jmp     short Ih                ; if we get here, the divisor must be
                                        ; ...zero; go return infinity

        align 2
Ib2:    mov     bx,31                   ; calculate final scaling shift
        sub     bx,cx                   ; left shift (31-CX)
        mov     divscal,bx              ; store for later

; Quotient is formed by doing 31 iterations.
        mov     cx,31                   ; set loop counter
        sub     bx,bx                   ; clear quotient
        sub     bp,bp

Ic:     shl     bp,1                    ; open next quotient position
        rcl     bx,1
        cmp     si,dx                   ; test for subtraction in this position
        ja      short Ie0               ; dvsr>dvnd: skip subtract
        jb      short Id                ; dvsr<dvnd: go subtract
        cmp     di,ax                   ; dvsr=dvnd: compare l/o portion
        ja      short Ie0               ; dvsr>dvnt: skip subtract

Id:     sub     ax,di                   ; calculate dividend - divisor
        sbb     dx,si
        or      bp,1                    ; insert quotient bit

Ie0:    shl     ax,1                    ; shift dividend left 1 bit
        rcl     dx,1
        loop    ic                      ; continue until count exhausted

; Shift quotient left by DIVSCAL amount (- means right)
        mov     cx,divscal              ; shift count
        or      cx,cx                   ; test for direction
        jz      short Ie4               ; 0: no shift needed
        js      short Ie2               ; s: negative (right shift)

Ie1:    shl     bp,1                    ; shift divisor left 1 bit
        rcl     bx,1
        jo      short Ih                ; overflow: result too large
        loop    ie1
        jmp     short Ie4

        align 2
Ie2:    neg     cx                      ; negate shift amount
Ie3:    shr     bx,1                    ; shift right 1 bit
        rcr     bp,1
        loop    ie3

Ie4:    test    sgnres,080h             ; test result sign
        jz      short If0               ; 0: positive
        neg     bx                      ; negate result
        neg     bp
        sbb     bx,0

If0:    mov     dx,bx                   ; return result in registers
        mov     ax,bp
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Ih:     test    sgnres,080h             ; test sign of result
        jz      short Ii                ; 0: positive
        mov     dx,neginfhi             ; negative: use NEGINF for return value
        mov     ax,neginflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller

        align 2
Ii:     mov     dx,posinfhi             ; positive: use POSINF for return value
        mov     ax,posinflo
        pop     di
        pop     si
        pop     bp
        ret                             ; return to caller
        ENDFUNC fixratio
        page
        COMMENT !


        fracsqrt: Calculate UFrac-Format Square Root

        Calculates the square root of the argument, which is interpreted
        as an unsigned fixed-point number having a 2-bit integer part and
        a 30-bit fraction part (UFrac format).

        The result is accurate to the full precision of the format.

        The algorithm used is the usual Newton-Raphson iteration tech-
        nique.  The number of iterations necessary depends upon the
        precision required, and the quality of the initial estimate.

        This program uses a table lookup based on the most significant
        portion of the argument to obtain a very good initial estimate.
        It is good enough that only two iterations of the loop are
        required; here, the loop is unrolled.

        The following table provides the initial estimate.  The values
        are 16-bit fractions, with the binary point to the left of bit
        15.  There are 128 entries in the table, with the i-th entry
        giving the value of sqrt(i / 128).

        !
        .data
table   equ     this word
        dw      00000h, 016a1h, 02000h, 02731h, 02d41h, 03299h, 0376dh, 03bdeh
        dw      04000h, 043e2h, 0478eh, 04b0ch, 04e62h, 05196h, 054aah, 057a3h
        dw      05a82h, 05d4ch, 06000h, 062a1h, 06531h, 067b1h, 06a22h, 06c84h
        dw      06edah, 07123h, 07361h, 07593h, 077bch, 079dah, 07befh, 07dfch
        dw      08000h, 081fch, 083f0h, 085deh, 087c4h, 089a3h, 08b7ch, 08d4fh
        dw      08f1ch, 090e3h, 092a4h, 09461h, 09618h, 097cah, 09977h, 09b20h
        dw      09cc4h, 09e64h, 0a000h, 0a198h, 0a32bh, 0a4bbh, 0a647h, 0a7cfh
        dw      0a954h, 0aad5h, 0ac53h, 0adceh, 0af45h, 0b0bah, 0b22bh, 0b399h
        dw      0b505h, 0b66eh, 0b7d3h, 0b937h, 0ba97h, 0bbf5h, 0bd51h, 0bea9h
        dw      0c000h, 0c154h, 0c2a6h, 0c3f6h, 0c543h, 0c68eh, 0c7d7h, 0c91eh
        dw      0ca63h, 0cba6h, 0cce6h, 0ce25h, 0cf62h, 0d09dh, 0d1d7h, 0d30eh
        dw      0d444h, 0d577h, 0d6aah, 0d7dah, 0d909h, 0da36h, 0db62h, 0dc8bh
        dw      0ddb4h, 0dedbh, 0e000h, 0e124h, 0e246h, 0e367h, 0e487h, 0e5a5h
        dw      0e6c1h, 0e7ddh, 0e8f7h, 0ea0fh, 0eb27h, 0ec3dh, 0ed51h, 0ee65h
        dw      0ef77h, 0f088h, 0f198h, 0f2a7h, 0f3b4h, 0f4c1h, 0f5cch, 0f6d6h
        dw      0f7dfh, 0f8e7h, 0f9eeh, 0faf3h, 0fbf8h, 0fcfbh, 0fdfeh, 0feffh

fracsqrt_ent dw offset fracsqrt0
fracsqrt_386 dw offset fracsqrt3
fracsqrt_286 dw offset fracsqrt2

        .code
        FUNC    fracsqrt
        jmp     fracsqrt_ent

fracsqrt0:
        call    procset                 ; test processor and set jump addresses
        jmp     fracsqrt_ent            ; go do the function
        page
; 80386/80486 Code for fracsqrt

        align 2
        .386
fracsqrt3:
        push    bp
        mov     bp,sp

; Test for zero-valued argument
        mov     eax,[@P]                ; fetch argument
        or      eax,eax                 ; test for zero
        jz      short b                 ; <= 0: return 0 immediately

; Form initial estimate of square root
        mov     ebx,eax                 ; get argument value
        bsr     ecx,ebx                 ; locate most significant bit
        neg     ecx
        add     ecx,31
        shr     ecx,1                   ; convert to even value
        shl     ecx,1                   ;   = i
        shl     ebx,cl                  ; left justify argument
        shr     ebx,25                  ; move high seven bits to low end
        shl     ebx,1                   ; convert to word index
        mov     dx,table[ebx]           ; get estimate from table
        shl     edx,16
        shr     ecx,1                   ; calculate 1 + i / 2
        inc     ecx
        shr     edx,cl                  ; scale estimate
        mov     ecx,edx                 ; keep in ECX for the duration

; Newton-Raphson loop: Divide n by estimate; new est = (est + quot) / 2
; (This is an unrolled loop with two iterations.)
        mov     ebx,eax                 ; keep original argument in EBX
        sub     edx,edx                 ; pre-scale EDX:EAX (dividend)
        shld    edx,eax,30
        shl     eax,30
        div     ecx                     ; divide by estimate
        add     ecx,eax                 ; average of q and e becomes estimate
        rcr     ecx,1                   ; h/o bit may be in Carry Flag
        mov     eax,ebx                 ; get argument again
        sub     edx,edx                 ; pre-scale EDX:EAX (dividend)
        shld    edx,eax,31              ; shift EDX:EAX left 31
        shl     eax,31
        div     ecx                     ; divide by estimate
        shr     eax,1
        add     eax,ecx                 ; average
        rcr     eax,1
        jnc     short b                 ; round
        inc     eax
b:      mov     dx,ax                   ; l/o part of result to DX
        shr     eax,16                  ; h/o part of result to AX
        xchg    dx,ax                   ; proper form for return value
        pop     bp
        ret                             ; return to caller; result in EAX
        page
; 8086/80286 Code for fracsqrt

;       Algorithm: Same as 386-fracsqrt above, except 32-bit division is
;       performed by repeated subtraction of a 32-bit divisor from a
;       32-bit dividend.

;       In order to prevent loss of precision, small numbers (0x0000nnnn)
;       are scaled up by 2**16 before the square-root operation is
;       performed and the result is scaled down by 2**8 afterward.
;
;       Register usage:
;          DX AX: argument, dividend
;          SI DI: estimate, divisor
;          BX BP: quotient
;          CX:    loop counter

        align 2
        .8086
fracsqrt2:
        push    bp                      ; establish frame pointer
        mov     bp,sp
        push    si
        push    di

; On entry, argument is on stack
        mov     ax,word ptr [@P]        ; get l/o argument
        mov     dx,word ptr [@P+2]      ; get h/o argument
        mov     si,ax                   ; test for zero
        or      si,dx
        jz      Sk                      ; if zero, return with zero result

; Check for small number (i.e. < 2**-16)
        mov     sqrtscal,0              ; reset scaling indicator
        or      dx,dx
        jnz     Sa0                     ; if not zero, don't scale up
        xchg    ax,dx                   ; equivalent to * 2**16
        mov     sqrtscal,1              ; set indicator

; Form initial estimate of square root
Sa0:    push    ax                      ; save argument on stack
        push    dx
        mov     si,dx                   ; get argument value and
        mov     di,ax                   ; ...locate most significant bit
        mov     cx,0                    ; initialize counter
Sa:     test    si,0c000h               ; test two high-order bits
        jnz     short Sb
        shl     di,1                    ; shift SI:DI left two bits
        rcl     si,1
        shl     di,1
        rcl     si,1
        inc     cx                      ; increment counter
        jmp     short Sa                ; test again
Sb:     push    cx                      ; save counter
        mov     cx,9
        shr     si,cl                   ; move high seven bits to low end
        shl     si,1                    ; convert to word index
        pop     cx                      ; restore counter
        inc     cx
        mov     si,table[si]            ; get estimate from table
        sub     di,di
Sc:     shr     si,1                    ; shift SI:DI right by CX amount
        rcr     di,1
        loop    Sc

; Newton-Raphson loop: Divide n by estimate; new est = (est + quot) / 2
; (This is an unrolled loop with two iterations.)

; Divide-by-subtraction loop
        shr     dx,1                    ; pre-scale dividend
        rcr     ax,1
        mov     cx,32                   ; set loop counter
        sub     bx,bx                   ; clear quotient
        sub     bp,bp
Sd:     shl     bp,1                    ; open next quotient position
        rcl     bx,1
        cmp     si,dx                   ; test for subtraction in this position
        ja      short Sf                ; dvsr>dvnd: skip subtract
        jb      short Se                ; dvsr<dvnd: go subtract
        cmp     di,ax                   ; dvsr=dvnd: compare l/o portion
        ja      short Sf                ; dvsr>dvnt: skip subtract
Se:     sub     ax,di                   ; calculate dividend - divisor
        sbb     dx,si
        or      bp,1                    ; insert quotient bit
Sf:     shl     ax,1                    ; shift dividend left 1 bit
        rcl     dx,1
        loop    Sd                      ; continue until count exhausted

; Calculate average of quotient and estimate
        add     di,bp                   ; add l/o quotient to l/o estimate
        adc     si,bx                   ; add h/o parts
        rcr     si,1                    ; divide by two - h/o bit is in Carry
        rcr     di,1

        pop     dx                      ; get argument again
        pop     ax

; Do the same thing a second time
        shr     dx,1                    ; pre-scale dividend
        rcr     ax,1
        mov     cx,32                   ; set loop counter
        sub     bx,bx                   ; clear quotient
        sub     bp,bp
Sg:     shl     bp,1                    ; open next quotient position
        rcl     bx,1
        cmp     si,dx                   ; test for subtraction in this position
        ja      short Sj                ; dvsr>dvnd: skip subtract
        jb      short Sh                ; dvsr<dvnd: go subtract
        cmp     di,ax                   ; dvsr=dvnd: compare l/o portion
        ja      short Sj                ; dvsr>dvnt: skip subtract
Sh:     sub     ax,di                   ; calculate dividend - divisor
        sbb     dx,si
        or      bp,1                    ; insert quotient bit
Sj:     shl     ax,1                    ; shift dividend left 1 bit
        rcl     dx,1
        loop    Sg                      ; continue until count exhausted

; Calculate average of quotient and estimate
        add     di,bp                   ; add l/o quotient to l/o estimate
        adc     si,bx                   ; add h/o parts
        rcr     si,1                    ; divide by two - h/o bit is in Carry
        rcr     di,1
        jnc     short Sj0               ; round
        add     di,1                    ; N.B.: inc does not set Carry Flag
        adc     si,0
Sj0:    mov     ax,di                   ; move SI:DI to function value regs
        mov     dx,si

; If we scaled up at the beginning, scale down again
        test    sqrtscal,0ffh           ; test indicator
        jz      Sk                      ; zero means no scaling
        add     ax,0080h                ; round by adding 1/2 of lsb of result
        add     dx,0                    ; propagate carry
        mov     al,ah                   ; shift it all right by 8 ( div by 256)
        mov     ah,dl
        mov     dl,dh
        sub     dh,dh

Sk:     pop     di
        pop     si
        pop     bp
        ret
        ENDFUNC fracsqrt
        page
        COMMENT !

        PROCSET: Internal Procedure to Determine Processor Type

        Sets branches for each of the public functions to use code appropriate
        for the processor in use.

        This procedure is called the first time any routine is entered, and
        only once.
        !

        align 2
        .386p
procset PROC    near
        pushf                           ; save flags
        push    cx                      ; save registers
        push    bp

        mov     ax,sp                   ; distinguish 8086/186 from higher mdls
        push    sp                      ; 86/186 will push sp-2; others: sp
        pop     cx
        cmp     ax,cx
        jne     short set2              ; ne: 8086 or 80186; go set branches

        sub     sp,6                    ; distinguish 286 from 386/486
        mov     bp,sp
        sgdt    fword ptr ss:[bp]       ; save GDTR on stack - store 6 bytes
        add     sp,4                    ; drop first four bytes
        pop     ax                      ; retrieve other two from stack
                                        ;   6th byte: 0xff for 286
                                        ;             0 or 1 for 386
        inc     ah
;       jmp     short set2              ; uncomment this line to force 286 code
        jnz     short set3              ; nz: must be 386/486

set2:                                   ; set branches for 86/186/286
        mov     ax,fixmul_286
        mov     fixmul_ent,ax
        mov     ax,frcmul_286
        mov     frcmul_ent,ax
        mov     ax,fixdiv_286
        mov     fixdiv_ent,ax
        mov     ax,fixrat_286
        mov     fixrat_ent,ax
        mov     ax,fracsqrt_286
        mov     fracsqrt_ent,ax
        jmp     short rtn
set3:
        mov     ax,fixmul_386           ; set branches for 386/486
        mov     fixmul_ent,ax
        mov     ax,frcmul_386
        mov     frcmul_ent,ax
        mov     ax,fixdiv_386
        mov     fixdiv_ent,ax
        mov     ax,fixrat_386
        mov     fixrat_ent,ax
        mov     ax,fracsqrt_386
        mov     fracsqrt_ent,ax
rtn:    pop     bp
        pop     cx
        popf
        ret
procset ENDP

        END

#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..

IS_16 = TRUE
IS_OEM = TRUE

!include ..\pscript2.mk


##-------------------------------------------------------------------
#               DIRECTORIES

#DRVRDIR is where the driver code lives.
DRVRDIR = ..

#CONTDIR is where the CONTROL code lives.
CONTDIR = ..\CONT\$(VERDIR)

#TRANDIR is where the TRANSLATION code lives.
TRANDIR = ..\TRAN\$(VERDIR)

#DMGDIR is where the DMG code lives.
DMGDIR = ..\DMG\$(VERDIR)

#STREAMERDIR is where the STREAMER code lives.
STREAMERDIR = ..\STREAMER\$(VERDIR)

#OEMSAMPL is where the OEMSAMPL code lives.
OEMSAMPLDIR = ..\OEMSAMPL\$(VERDIR)

#WPXDIR is where the WPX parser code lives
WPXDIR = ..\WPX\$(VERDIR)

#ENUMDIR is where the ENUMEREATOR code lives.
#ENUMDIR = ..\..\ENUM21\$(VERDIR)

#RESDIR is where the RESOURCES  live.
RESDIR = ..\RESOURCE

#XCFDIR is where the RESOURCES  live.
XCFDIR = ..\XCF

#UFL is where the RESOURCES  live.
UFLDIR = ..\UFL\$(VERDIR)



##-------------------------------------------------------------------

#
#   Various flags for linker
#

!if "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
L16FLAGS=/AL:32 /NOD /NOE  /CO /LI /MAP /SEG:256
!else
L16FLAGS=/AL:16 /NOD /NOE /MAP /SEG:256 /PACKF
!endif

!ifndef DBCS  # US Version def files.
PS_PROF_DEF=psprofil.def
PS_NORM_DEF=pswriter.def
!else         # FE Version def files.
PS_PROF_DEF=psprdbcs.def
PS_NORM_DEF=pswrdbcs.def
!endif

!if (defined(PS_PROFILE) || defined(STATPROF))
PS_DEFFILE=$(PS_PROF_DEF)
!else
PS_DEFFILE=$(PS_NORM_DEF)
!endif

#taken out the XCF for now
#    $(XCFDIR)\xcf.lib\

#    place this after @<<
#    $(XCFDIR)\xcf.lib 


#The main target is the Driver module.
pscript2.drv: $(CONTDIR)\LIBENTRY.OBJ $(CONTDIR)\cont.lib $(DMGDIR)\dmg.lib\
    $(TRANDIR)\tran.lib $(WPXDIR)\wpx.lib\
    $(STREAMERDIR)\streamer.lib\
    $(UFLDIR)\ufl.lib\
    $(RESDIR)\pswriter.res $(DRVRDIR)\$(PS_DEFFILE)
   $(LINK16) @<<
$(L16FLAGS)+
$(CONTDIR)\LIBENTRY.OBJ,pscript2.drv,pscript2.map,
ldllcew libw ver $(CONTDIR)\cont.lib $(DMGDIR)\dmg.lib $(TRANDIR)\tran.lib+
$(STREAMERDIR)\streamer.lib+
$(UFLDIR)\ufl.lib+
$(WPXDIR)\wpx.lib,
$(DRVRDIR)\$(PS_DEFFILE);
<<NOKEEP

   rc -v -k $(RESDIR)\pswriter.res pscript2.drv
   mapsym -n pscript2.map


!ifdef DBCS  # DBCS Version def file
$(DRVRDIR)\psprdbcs.def: $(DRVRDIR)\psprofil.def
   sed "s/^;DBCS://" < $(DRVRDIR)\psprofil.def > $(DRVRDIR)\psprdbcs.def

$(DRVRDIR)\pswrdbcs.def: $(DRVRDIR)\pswriter.def
   sed "s/^;DBCS://" < $(DRVRDIR)\pswriter.def > $(DRVRDIR)\pswrdbcs.def
!endif

default : pscript2.drv
all     : pscript2.drv



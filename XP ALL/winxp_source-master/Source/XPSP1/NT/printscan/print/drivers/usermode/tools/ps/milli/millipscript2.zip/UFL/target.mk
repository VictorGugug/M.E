#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..\source
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!include ..\ufl.mk


!IF "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT = /Od /Zi /G2 /DPSDEBUG
OPTSPECIAL=/Od /Zi
!ELSE
DBGOPT=/DRELEASE /Ose /G3
OPTSPECIAL=/Od
!ENDIF

OPTS   = /c /W3 /ALw /Gsy /nologo
OPTX   = /Zdp1

!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fa
!endif

AFLAGS = /c /Zm /Dmdl_l
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver

!ifdef DBCS
# For FE.
CFLAGS = $(CFLAGS) /DFE_DEVICE
!endif

#  L16EXE = krnl386.exe
#  PROPBINS=$(L16EXE) krnl386.sym krnl386s.sym
#  TARGETS = $(PROPBINS)
#  MFLAGS = -m -nologo

INCLUDE = ..\..\inc;$(ROOT)\printers\drivers\iconlib;$(ROOT)\dev\ddk\inc;$(INCLUDE);..\config\win;..\api;..\xcf

#List of object files to build:
OBJS   = PARSETT.OBJ UFL.OBJ UFLMEM.OBJ UFLSPROC.OBJ UFLSTRM.OBJ\
UFO.OBJ UFOCFF.OBJ UFOT42.OBJ UFOTTT1.OBJ UFOTTT3.OBJ

ufl.lib: $(OBJS)
   $(LB) ufl.lib @<<
-+$(OBJS: = &^
-+)
ufl.lst;

<<NOKEEP

default : $(OBJS) ufl.lib

all     :  $(OBJS) ufl.lib



GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

generic.obj: ..\source\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\source\generic.c


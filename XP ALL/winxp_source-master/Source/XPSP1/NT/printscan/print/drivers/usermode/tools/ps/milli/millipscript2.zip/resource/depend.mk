!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

.\ocutils2.obj .\ocutils2.lst: .\ocutils2.cpp
.PRECIOUS: .\ocutils2.lst

.\encoding.obj .\encoding.lst: .\encoding.c \
	$(DEVROOT)\tools\c816\inc\assert.h \
	$(DEVROOT)\tools\c816\inc\stdio.h \
	$(DEVROOT)\tools\c816\inc\stdlib.h \
	$(DEVROOT)\tools\c816\inc\string.h .\encoding.h \
	.\tokens.h
.PRECIOUS: .\encoding.lst

.\lex_yy.obj .\lex_yy.lst: .\lex_yy.c \
	$(DEVROOT)\tools\c816\inc\assert.h \
	$(DEVROOT)\tools\c816\inc\ctype.h \
	$(DEVROOT)\tools\c816\inc\limits.h \
	$(DEVROOT)\tools\c816\inc\stdarg.h \
	$(DEVROOT)\tools\c816\inc\stdio.h \
	$(DEVROOT)\tools\c816\inc\stdlib.h \
	$(DEVROOT)\tools\c816\inc\string.h .\encoding.h \
	.\tokens.h
.PRECIOUS: .\lex_yy.lst

.\makecmap.obj .\makecmap.lst: .\makecmap.c \
	$(DEVROOT)\inc16\commctrl.h \
	$(DEVROOT)\inc16\commdlg.h \
	$(DEVROOT)\inc16\prsht.h \
	$(DEVROOT)\inc16\windows.h \
	$(DEVROOT)\inc16\windowsx.h \
	$(DEVROOT)\sdk\inc16\print.h \
	$(DEVROOT)\sdk\inc16\winerror.h \
	$(DEVROOT)\tools\c816\inc\assert.h \
	$(DEVROOT)\tools\c816\inc\direct.h \
	$(DEVROOT)\tools\c816\inc\dos.h \
	$(DEVROOT)\tools\c816\inc\io.h \
	$(DEVROOT)\tools\c816\inc\limits.h \
	$(DEVROOT)\tools\c816\inc\math.h \
	$(DEVROOT)\tools\c816\inc\memory.h \
	$(DEVROOT)\tools\c816\inc\setjmp.h \
	$(DEVROOT)\tools\c816\inc\stdlib.h \
	$(DEVROOT)\tools\c816\inc\time.h \
	$(DEVROOT)\ddk\inc16\gdidefs.inc \
	..\..\$(MYDIR)\inc\advanced.h \
	..\..\$(MYDIR)\inc\atm.h \
	..\..\$(MYDIR)\inc\bitmap.h \
	..\..\$(MYDIR)\inc\cfont.h \
	..\..\$(MYDIR)\inc\cfuncs.h \
	..\..\$(MYDIR)\inc\clrdlg.h \
	..\..\$(MYDIR)\inc\concatx.h \
	..\..\$(MYDIR)\inc\csprof.h \
	..\..\$(MYDIR)\inc\custpap.h \
	..\..\$(MYDIR)\inc\dbcs.h \
	..\..\$(MYDIR)\inc\devcapex.h \
	..\..\$(MYDIR)\inc\device.h \
	..\..\$(MYDIR)\inc\devmode.h \
	..\..\$(MYDIR)\inc\devmode2.h \
	..\..\$(MYDIR)\inc\dlgid.h \
	..\..\$(MYDIR)\inc\dlgsutil.h \
	..\..\$(MYDIR)\inc\drvfuncs.h \
	..\..\$(MYDIR)\inc\drvrdll.h \
	..\..\$(MYDIR)\inc\drvrmem.h \
	..\..\$(MYDIR)\inc\drvstate.h \
	..\..\$(MYDIR)\inc\enable.h \
	..\..\$(MYDIR)\inc\encode.h \
	..\..\$(MYDIR)\inc\enumfont.h \
	..\..\$(MYDIR)\inc\enumobj.h \
	..\..\$(MYDIR)\inc\enumstub.h \
	..\..\$(MYDIR)\inc\enumx.h \
	..\..\$(MYDIR)\inc\epsfuncs.h \
	..\..\$(MYDIR)\inc\errorid.h \
	..\..\$(MYDIR)\inc\errors.h \
	..\..\$(MYDIR)\inc\escapes.h \
	..\..\$(MYDIR)\inc\escmg.h \
	..\..\$(MYDIR)\inc\file.h \
	..\..\$(MYDIR)\inc\fntcache.h \
	..\..\$(MYDIR)\inc\fonthdr.h \
	..\..\$(MYDIR)\inc\fonts.h \
	..\..\$(MYDIR)\inc\generic.h \
	..\..\$(MYDIR)\inc\getcharw.h \
	..\..\$(MYDIR)\inc\getcrd.h \
	..\..\$(MYDIR)\inc\getcsa.h \
	..\..\$(MYDIR)\inc\glstatic.h \
	..\..\$(MYDIR)\inc\graphics.h \
	..\..\$(MYDIR)\inc\icc.h \
	..\..\$(MYDIR)\inc\icc_i386.h \
	..\..\$(MYDIR)\inc\icm.h \
	..\..\$(MYDIR)\inc\jobdlg.h \
	..\..\$(MYDIR)\inc\keywfunc.h \
	..\..\$(MYDIR)\inc\lcalls.h \
	..\..\$(MYDIR)\inc\margins.h \
	..\..\$(MYDIR)\inc\mmfonts.h \
	..\..\$(MYDIR)\inc\oem.h \
	..\..\$(MYDIR)\inc\oemplugi.h \
	..\..\$(MYDIR)\inc\oemstubs.h \
	..\..\$(MYDIR)\inc\oldwpd.h \
	..\..\$(MYDIR)\inc\paper.h \
	..\..\$(MYDIR)\inc\pfmparse.h \
	..\..\$(MYDIR)\inc\pixel.h \
	..\..\$(MYDIR)\inc\port.h \
	..\..\$(MYDIR)\inc\ppdparse.h \
	..\..\$(MYDIR)\inc\printcap.h \
	..\..\$(MYDIR)\inc\prntrmgr.h \
	..\..\$(MYDIR)\inc\ps.h \
	..\..\$(MYDIR)\inc\ps_debug.h \
	..\..\$(MYDIR)\inc\ps_enumx.h \
	..\..\$(MYDIR)\inc\psdebug.h \
	..\..\$(MYDIR)\inc\psdlg.h \
	..\..\$(MYDIR)\inc\qfile.h \
	..\..\$(MYDIR)\inc\qtokens.h \
	..\..\$(MYDIR)\inc\realize.h \
	..\..\$(MYDIR)\inc\resourcx.h \
	..\..\$(MYDIR)\inc\resrcid.h \
	..\..\$(MYDIR)\inc\statmach.h \
	..\..\$(MYDIR)\inc\status.h \
	..\..\$(MYDIR)\inc\stretchb.h \
	..\..\$(MYDIR)\inc\stretchd.h \
	..\..\$(MYDIR)\inc\sysrsrc.h \
	..\..\$(MYDIR)\inc\tflavors.h \
	..\..\$(MYDIR)\inc\trans.h \
	..\..\$(MYDIR)\inc\truetype.h \
	..\..\$(MYDIR)\inc\tstubs.h \
	..\..\$(MYDIR)\inc\ttdialog.h \
	..\..\$(MYDIR)\inc\ttext.h \
	..\..\$(MYDIR)\inc\ttfonts.h \
	..\..\$(MYDIR)\inc\ttfonts2.h \
	..\..\$(MYDIR)\inc\tutils.h \
	..\..\$(MYDIR)\inc\uic.h \
	..\..\$(MYDIR)\inc\unconcat.h \
	..\..\$(MYDIR)\inc\upgrade.h \
	..\..\$(MYDIR)\inc\utils.h \
	..\..\$(MYDIR)\inc\vmem.h \
	..\..\$(MYDIR)\inc\watermar.h \
	..\..\$(MYDIR)\inc\wpxinfo.h \
	..\..\$(MYDIR)\inc\wstdarg.h \
	$(ROOT)\printers\drivers\iconlib\icons.h \
	.\..\cont\cont.h .\..\dmg\chicago.h .\..\dmg\dlgsfunc.h \
	.\..\dmg\dmg.h .\..\tran\lv1funcs.h .\..\tran\lv2funcs.h \
	.\..\tran\pswtrans.h .\..\tran\ttfonts2.c .\..\wpx\fproto.h \
	.\resource.h
.PRECIOUS: .\makecmap.lst

.\mapname.obj .\mapname.lst: .\mapname.c \
	$(DEVROOT)\tools\c816\inc\assert.h \
	$(DEVROOT)\tools\c816\inc\stdio.h \
	$(DEVROOT)\tools\c816\inc\string.h .\sysnames.h
.PRECIOUS: .\mapname.lst

.\pshrink.obj .\pshrink.lst: .\pshrink.c \
	$(DEVROOT)\tools\c816\inc\limits.h \
	$(DEVROOT)\tools\c816\inc\stdarg.h \
	$(DEVROOT)\tools\c816\inc\stdio.h \
	$(DEVROOT)\tools\c816\inc\stdlib.h .\encoding.h
.PRECIOUS: .\pshrink.lst

.\smash.obj .\smash.lst: .\smash.c \
	$(DEVROOT)\tools\c816\inc\ctype.h \
	$(DEVROOT)\tools\c816\inc\stdio.h \
	$(DEVROOT)\tools\c816\inc\stdlib.h \
	$(DEVROOT)\tools\c816\inc\string.h
.PRECIOUS: .\smash.lst

.\ps.res .\ps.lst: .\ps.rc $(DEVROOT)\inc16\prsht.h \
	$(DEVROOT)\inc16\windows.h \
	$(DEVROOT)\inc16\windowsx.h \
	$(DEVROOT)\sdk\inc16\colordlg.h \
	$(DEVROOT)\sdk\inc16\dlgs.h \
	$(DEVROOT)\sdk\inc16\print.h \
	$(DEVROOT)\ddk\inc16\gdidefs.inc \
	..\..\$(MYDIR)\inc\devmode.h \
	..\..\$(MYDIR)\inc\dlgid.h \
	..\..\$(MYDIR)\inc\errors.h \
	..\..\$(MYDIR)\inc\escmg.h \
	..\..\$(MYDIR)\inc\fonthdr.h \
	..\..\$(MYDIR)\inc\icc.h \
	..\..\$(MYDIR)\inc\icc_i386.h \
	..\..\$(MYDIR)\inc\icm.h \
	..\..\$(MYDIR)\inc\printcap.h \
	..\..\$(MYDIR)\inc\ps.h \
	..\..\$(MYDIR)\inc\ps_debug.h \
	..\..\$(MYDIR)\inc\resrcid.h \
	..\..\$(MYDIR)\inc\spin.h \
	..\..\$(MYDIR)\inc\ttfonts2.h \
	..\..\$(MYDIR)\inc\upgrade.h \
	$(ROOT)\printers\drivers\iconlib\icons.h .\ps.dlg
.PRECIOUS: .\ps.lst

.\pswriter.res .\pswriter.lst: .\pswriter.rc \
	$(DEVROOT)\inc16\prsht.h \
	$(DEVROOT)\inc16\windows.h \
	$(DEVROOT)\inc16\windowsx.h \
	$(DEVROOT)\sdk\inc16\colordlg.h \
	$(DEVROOT)\sdk\inc16\dlgs.h \
	$(DEVROOT)\sdk\inc16\print.h \
	$(DEVROOT)\sdk\inc16\ver.h \
	$(DEVROOT)\ddk\inc16\gdidefs.inc \
	..\..\$(MYDIR)\inc\devmode.h \
	..\..\$(MYDIR)\inc\dlgid.h \
	..\..\$(MYDIR)\inc\errors.h \
	..\..\$(MYDIR)\inc\escmg.h \
	..\..\$(MYDIR)\inc\fonthdr.h \
	..\..\$(MYDIR)\inc\icc.h \
	..\..\$(MYDIR)\inc\icc_i386.h \
	..\..\$(MYDIR)\inc\icm.h \
	..\..\$(MYDIR)\inc\oldwpd.h \
	..\..\$(MYDIR)\inc\printcap.h \
	..\..\$(MYDIR)\inc\ps.h \
	..\..\$(MYDIR)\inc\ps_debug.h \
	..\..\$(MYDIR)\inc\resrcid.h \
	..\..\$(MYDIR)\inc\spin.h \
	..\..\$(MYDIR)\inc\ttfonts2.h \
	..\..\$(MYDIR)\inc\upgrade.h \
	$(ROOT)\printers\drivers\iconlib\icons.h .\adobeps.rcv \
        .\ename.rcd .\fonts.rcd .\ps.dlg .\psver.h .\nonlocal.rc .\localfnt.rcd
.PRECIOUS: .\pswriter.lst

.\x.res .\x.lst: .\x.rc $(DEVROOT)\inc16\prsht.h \
	$(DEVROOT)\inc16\windows.h \
	$(DEVROOT)\inc16\windowsx.h \
	$(DEVROOT)\sdk\inc16\colordlg.h \
	$(DEVROOT)\sdk\inc16\dlgs.h \
	$(DEVROOT)\sdk\inc16\print.h \
	$(DEVROOT)\ddk\inc16\gdidefs.inc \
	..\..\$(MYDIR)\inc\devmode.h \
	..\..\$(MYDIR)\inc\escmg.h \
	..\..\$(MYDIR)\inc\fonthdr.h \
	..\..\$(MYDIR)\inc\icc.h \
	..\..\$(MYDIR)\inc\icc_i386.h \
	..\..\$(MYDIR)\inc\icm.h \
	..\..\$(MYDIR)\inc\printcap.h \
	..\..\$(MYDIR)\inc\ps_debug.h \
	..\..\$(MYDIR)\inc\ttfonts2.h \
	$(ROOT)\printers\driverss\iconlib\icons.h \
	.\..\inc\dlgid.h .\..\inc\errors.h .\..\inc\ps.h \
	.\..\inc\resrcid.h .\..\inc\spin.h .\..\inc\upgrade.h .\resource.h
.PRECIOUS: .\x.lst


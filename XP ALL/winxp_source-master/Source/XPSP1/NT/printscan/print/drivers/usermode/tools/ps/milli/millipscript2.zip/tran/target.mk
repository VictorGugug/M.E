#############################################################################
#
#       Microsoft Confidential
#       Copyright (C) Microsoft Corporation 1992
#       All Rights Reserved.
#
#       Makefile for krnl386
#
#############################################################################
ROOT = ..\..\..\..\..\..
SRCDIR = ..
#  MESSAGES = ..\messages
IS_16 = TRUE
IS_OEM = TRUE
DEPENDNAME = ..\depend.mk

!IF "$(PS2DIR)" == ""
MYDIR=pscript2
!ELSE
MYDIR=$(PS2DIR)
!ENDIF

!IFNDEF PS41DIR
PS41DIR=ps40
!ENDIF


!include ..\tran.MK

!IF "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
DBGOPT = /Od /Zi /G2 /DPSDEBUG
OPTSPECIAL=/Od /Zi
!ELSE
DBGOPT=/DRELEASE /Ose /G3
OPTSPECIAL=/Od
!ENDIF

OPTS   = /c /W3 /ALw /Gsy /nologo
OPTX   = /Zdp1

!ifdef ADOBE_WEB
OPTS=$(OPTS) /DADOBE_WEB
!endif

!ifdef PS_PROFILE
LCFLAGS=$(LCFLAGS) /DPS_PROFILE
!endif
!ifdef STATPROF
LCFLAGS=$(LCFLAGS) /DSTATPROF
!endif
!ifdef PS_MEMTRACE
LCFLAGS=$(LCFLAGS) /DPS_MEMTRACE
!endif
!ifdef PS_ASMLISTING
LCFLAGS=$(LCFLAGS) /Fa
!endif

AFLAGS = /c /Zm /Dmdl_l
#CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) /YuGENERIC.H /Fp.\GENERIC.PCH
CFLAGS = $(OPTS) $(OPTX) $(DBGOPT) $(LCFLAGS) -DADOBE_DRIVER -DAdobe_Driver
#!ifdef STREAMER
CFLAGS = $(CFLAGS) -DPACKAGE_SPECS="\"..\\streamer\\package.h\""
#/DSTREAMER
#!endif

!ifdef DBCS
# For FE.
CFLAGS = $(CFLAGS) /DFE_DEVICE /DFE_BOLD
!endif

!ifdef T3OUTLINE
CFLAGS = $(CFLAGS) /DT3OUTLINE
!endif

!ifdef MICROSOFT_DRIVER_VERSION
CFLAGS = $(CFLAGS) -DMICROSOFT_DRIVER_VERSION
!endif

#s  L16EXE = krnl386.exe
#  PROPBINS=$(L16EXE) krnl386.sym krnl386s.sym
#  TARGETS = $(PROPBINS)
#  MFLAGS = -m -nologo

INCLUDE = ..\..\inc;$(ROOT)\printers\drivers\iconlib;$(ROOT)\dev\ddk\inc;$(INCLUDE);..\config\win;..\api;..\xcf
#INCLUDE = ..\..\inc;$(WINROOT)\drivers\printers\iconlib;$(WINROOT)\core\inc;$(INCLUDE);..\..\ufl\api;..\..\ufl\config\win


#List of object files to build:
#OBJS   = GENERIC.OBJ TRANS.OBJ PSDATA.OBJ TSTUBS.OBJ TGDIOBJ.OBJ TESCAPES.OBJ\
OBJS = TRANS.OBJ PSDATA.OBJ TSTUBS.OBJ TGDIOBJ.OBJ TESCAPES.OBJ\
TUTILS.OBJ ENCODE.OBJ TFLAVORS.OBJ LV2FUNCS.OBJ TTEXT.OBJ\
FSWITCH.OBJ EPSFUNCS.OBJ THEADER.OBJ TTFONTS.OBJ SCALE.OBJ VMEM.OBJ\
WM.OBJ mmfonts.obj ttfonts2.obj tmask.obj UFOENC.OBJ

#!ifdef STREAMER
OBJS = $(OBJS) STRMFONT.OBJ
#!endif

!ifdef T3OUTLINE
OBJS = $(OBJS) T3OUTLN.OBJ
!endif

!if "$(VERDIR)" == "debug" || "$(VERDIR)" == "debug.d"
OBJS = $(OBJS) PSDEBUG.OBJ
!endif

tran.lib: $(OBJS)
   $(LB) tran.lib @<<
-+$(OBJS: = &^
-+)
tran.lst;

<<NOKEEP

default : $(OBJS) tran.lib

all     : $(OBJS) tran.lib



GENCFLAGS = $(CFLAGS:/YuGENERIC.H=)
OLDCFLAGS = $(GENCFLAGS:/Fp.\GENERIC.PCH=)

generic.obj: ..\generic.c ..\..\inc\generic.h
        if exist *.obj del *.obj
        set CL=/YcGENERIC.H $(GENCFLAGS)
        $(CL) -Fo$*.obj ..\generic.c

